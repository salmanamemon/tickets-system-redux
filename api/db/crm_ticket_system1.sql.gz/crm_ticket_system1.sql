-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2022 at 03:55 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm_ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `auth` varchar(100) NOT NULL,
  `roles` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `company`, `address`, `phone`, `email`, `password`, `updated_at`, `auth`, `roles`) VALUES
(1, 'Salman Aziz', 'Company Name', 'Some address in Dubai', '234234234', 'memon.salman@gmail.com', '12345', '2021-11-03 08:59:59', '3bb157b671b7200bf55952961c20f064', '0'),
(2, 'Alex Joe', 'Company Name', 'Some address in Dubai', '234234234', 'alex@gmail.com', '$2a$10$aLKAOb7Z1PQZuuROtbhi8eTJ5LsgNZ4yDGCD3cKxCewdpthLeDzjW', '2021-11-03 09:16:25', '28150350-8853-4f93-887d-d5e24192a842', '1'),
(3, 'John Jim', 'Company Name', 'Some address in Dubai', '2342342342', 'john@gmail.com', '$2a$10$aLKAOb7Z1PQZuuROtbhi8eTJ5LsgNZ4yDGCD3cKxCewdpthLeDzjW', '2022-02-15 10:07:13', '78950350-8853-4f93-887d-d5e24192a142', '2');

-- --------------------------------------------------------

--
-- Table structure for table `ticketconversations`
--

CREATE TABLE `ticketconversations` (
  `id` int(11) NOT NULL,
  `message` varchar(150) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `ticketRef` int(50) NOT NULL,
  `msgAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketconversations`
--

INSERT INTO `ticketconversations` (`id`, `message`, `sender`, `ticketRef`, `msgAt`) VALUES
(1, 'this is the conversation message for ticket 1 ', 'Salman Aziz', 1, '2022-03-28 07:51:14'),
(2, 'this is the second conversation message for ticket 1 ', 'Salman Aziz', 1, '2022-03-28 07:51:14');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `detail` varchar(150) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `openAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `subject`, `detail`, `status`, `sender`, `openAt`) VALUES
(1, 'Email Jurna, njusto pharetra ', NULL, 'closed', 'memon.salman@gmail.com', '2022-03-23 05:48:38'),
(2, 'SSL ringilla vulputate', NULL, 'closed', 'memon.salman@gmail.com', '2022-03-23 05:48:38'),
(3, 'Network auris iaculis', NULL, 'pending', 'memon.salman@gmail.com', '2022-03-23 05:48:38'),
(4, 'Email psum dolor sit', NULL, 'pending', 'alex@gmail.com', '2022-03-23 05:48:38'),
(5, 'Datacenter ', NULL, 'pending', 'john@gmail.com', '2022-03-23 05:48:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticketconversations`
--
ALTER TABLE `ticketconversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ticketconversations`
--
ALTER TABLE `ticketconversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
